#!/bin/bash
cd "$(dirname "$0")"
command -v python3 >/dev/null || { echo "Python3 topilmadi: python.org dan o'rnating"; open https://www.python.org/downloads/; exit 1; }
mkdir -p ~/.streamlit; [ -f ~/.streamlit/credentials.toml ] || printf '[general]\nemail = ""\n' > ~/.streamlit/credentials.toml
if [ ! -f .installed ]; then
  python3 -m pip install -r requirements.txt || { grep -vi xgboost requirements.txt > req_min.txt; python3 -m pip install -r req_min.txt; } && touch .installed
fi
python3 -m streamlit run app.py
