"""Runs app.py with a FAKE streamlit/plotly to catch runtime errors on every page and language."""
import os, re, runpy, sys
from unittest.mock import MagicMock
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT); os.chdir(ROOT)


class SS(dict):
    __getattr__ = dict.get
    def __setattr__(self, k, v): self[k] = v


class W(MagicMock):
    def selectbox(self, label, options, index=0, **kw): return list(options)[index]
    def number_input(self, label, mn=None, mx=None, value=None, **kw): return value
    def text_input(self, label, value="", **kw): return value
    def checkbox(self, label, value=False, **kw): return value
    def button(self, *a, **kw): return False
    def file_uploader(self, *a, **kw): return None
    def columns(self, spec, **kw): return [W() for _ in range(spec if isinstance(spec, int) else len(spec))]


def run(page, lang):
    class SB(W):
        def radio(self, label, options, **kw): return lang if list(options) == ["uz", "ru"] else page
    st = W(); st.sidebar = SB(); st.session_state = SS()
    def cache(*a, **k):
        if a and callable(a[0]): a[0].clear = lambda: None; return a[0]
        def deco(fn): fn.clear = lambda: None; return fn
        return deco
    st.cache_data = cache; st.cache_resource = cache
    def stop(): raise SystemExit
    st.stop = stop
    for m in ("plotly", "plotly.express", "plotly.graph_objects"): sys.modules[m] = MagicMock()
    sys.modules["streamlit"] = st
    if page == "perf":
        from data.demo_data import make_demo
        from engine.backtest import run_backtest
        st.session_state["bt"] = run_backtest(make_demo(seasons=4), 300, 100, True)
    runpy.run_path("app.py", run_name="__main__")
    return st


if __name__ == "__main__":
    pages = ["dashboard", "upcoming", "analysis", "betman", "exact", "odds", "teams", "backtest", "perf", "sources"]
    bad = 0
    for lang in ("uz", "ru"):
        for p in pages:
            try: run(p, lang); print("OK  ", lang, p)
            except SystemExit: print("STOP", lang, p)
            except Exception as e: bad += 1; print("FAIL", lang, p, type(e).__name__, e)
    sys.exit(bad)
