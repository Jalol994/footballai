@echo off
cd /d "%~dp0"
title Football Analytics
python --version >nul 2>&1
if errorlevel 1 (
  echo.
  echo PYTHON TOPILMADI. Hozir sayt ochiladi: Python ni yuklab oling.
  echo O'rnatishda "Add Python to PATH" katakchasini BELGILANG.
  echo O'rnatgach, START.bat ni qayta ikki marta bosing.
  start https://www.python.org/downloads/
  pause
  exit /b
)
if not exist "%USERPROFILE%\.streamlit\credentials.toml" (
  mkdir "%USERPROFILE%\.streamlit" 2>nul
  (echo [general]& echo email = "") > "%USERPROFILE%\.streamlit\credentials.toml"
)
if not exist .installed (
  echo Birinchi marta: kutubxonalar o'rnatilmoqda (5-10 daqiqa, internet kerak)...
  python -m pip install -r requirements.txt
  if errorlevel 1 (
    echo xgboost'siz qayta urinilmoqda...
    findstr /v /i "xgboost" requirements.txt > req_min.txt
    python -m pip install -r req_min.txt
    if errorlevel 1 (
      echo XATO: o'rnatib bo'lmadi. Shu oynadagi xabarni menga yuboring.
      pause
      exit /b
    )
  )
  echo ok> .installed
)
echo Dastur ishga tushmoqda. Brauzer o'zi ochiladi. To'xtatish: shu oynani yoping.
python -m streamlit run app.py
pause
